package main.model;

public enum Type {
    RIVER, TRAP1, TRAP2, DEN1, DEN2, NORMAL
}
