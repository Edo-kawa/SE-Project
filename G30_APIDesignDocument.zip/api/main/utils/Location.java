package main.utils;

public class Location{

    private int r,i,c;

    public Location(int row, int column){

    }

    public Location(int index){

    }

    // Getters
    public int getRow(){
        return r;
    }

    public int getCol(){
        return c;
    }

    public int getIndex(){
        return i;
    }
}
