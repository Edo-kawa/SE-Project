package main.view;

import main.model.ChessBoard;
//import main.model.BoardStandard;
import main.model.Square;
import main.utils.Location;

import java.util.List;
import java.util.Scanner;


public class BoardView {
    private ChessBoard chessBoard;

    public ChessBoard getChessBoard() {
        return chessBoard;
    }

    public BoardView(ChessBoard model){

    }

    /**
     * print out the user interface
     */
    public void printChessBoard(){}
}
