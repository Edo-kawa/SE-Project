package main.utils;

import main.model.Pieces.*;

public class BoardBuilder {

    /**
     * Factory method for returning various types of pieces.
     * @param pieceName
     * @param sideName
     * @param row
     * @param col
     * @return
     */
    public static Piece PieceFactory(String pieceName,
                                     Side sideName, int row, int col){

        return null;

    }

}
